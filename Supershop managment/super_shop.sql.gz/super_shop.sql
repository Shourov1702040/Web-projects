-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2020 at 02:15 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `super_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `catalog`
--

CREATE TABLE `catalog` (
  `Cata_id` varchar(50) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Supply_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `catalog`
--

INSERT INTO `catalog` (`Cata_id`, `Category`, `Supply_date`) VALUES
('CT-100', 'Full Trouser', '02-05-2019'),
('CT-45', 'Half sleeve shirt', '02-05-2019'),
('CT-50', 'Full sleeve shirt', '02-05-2019'),
('CT-77', 'Three Quater Pant', '02-05-2019'),
('CT-90', 'Full Gence Pant', '02-05-2019');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `Contact_no` varchar(50) NOT NULL,
  `Suppliers_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Contact_no`, `Suppliers_id`) VALUES
('92454599966', 's-10005'),
('96333645777', 's-10006'),
('964537574535', 's-10008'),
('98233555325', 's-10004'),
('98346233333', 's-10006'),
('98362345456', 's-10003'),
('98453677777', 's-10007'),
('98534227888', 's-10005'),
('985352226533', 's-10008'),
('98555555646', 's-10002'),
('98563335475', 's-10002'),
('98565265475', 's-10002'),
('98565466346', 's-10004'),
('98666646656', 's-10003'),
('98886345645', 's-10007'),
('995647684', 's-10001'),
('996736673', 's-10001'),
('997773635', 's-10001');

-- --------------------------------------------------------

--
-- Table structure for table `counter`
--

CREATE TABLE `counter` (
  `C_id` varchar(50) NOT NULL,
  `Employee_Name` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Salary` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `counter`
--

INSERT INTO `counter` (`C_id`, `Employee_Name`, `Password`, `Salary`) VALUES
('Em-01', 'John Stuart', '1234', 500),
('Em-02', 'Andrew Emily', '1234', 500),
('Em-03', 'Daniel Lisa', '1234', 500),
('Em-04', 'Jack Sparrow', '1234', 550);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `P_id` varchar(50) NOT NULL,
  `Cata_id` varchar(50) NOT NULL,
  `Stock` int(255) NOT NULL,
  `Price` int(255) NOT NULL,
  `Supplier_name` varchar(60) NOT NULL,
  `Acc_rate` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`P_id`, `Cata_id`, `Stock`, `Price`, `Supplier_name`, `Acc_rate`) VALUES
('BS-1027', 'CT-77', 138, 33, 'Eliza Ibara', 22),
('BS-1039', 'CT-77', 146, 50, 'Eliza Ibara', 42),
('HT-1162', 'CT-100', 136, 46, 'Tyler Aiden', 33),
('KB-1033', 'CT-100', 141, 76, 'Tyler Aiden', 65),
('KB-1086', 'CT-100', 146, 23, 'William Ethan', 17),
('NC-1009', 'CT-77', 145, 50, 'Eliza Ibara', 40),
('SG-1002', 'CT-45', 146, 70, 'James Smith', 57),
('SG-1043', 'CT-45', 149, 56, 'James Smith', 46),
('SG-1047', 'CT-45', 143, 38, 'James Smith', 31),
('SG-1084', 'CT-50', 141, 29, 'Michael Anthony', 20),
('SG-1430', 'CT-50', 148, 35, 'William Jacob', 22),
('SK-1072', 'CT-50', 135, 48, 'Michael Anthony', 35),
('SS-1003', 'CT-77', 143, 40, 'William Jacob', 28),
('SS-1063', 'CT-90', 140, 42, 'Noah Samuel', 33),
('TQ-1099', 'CT-50', 140, 68, 'Michael Anthony', 55),
('TT-1028', 'CT-90', 145, 72, 'Noah Samuel', 61),
('TT-1029', 'CT-90', 147, 43, 'Logaan Jackson', 34);

-- --------------------------------------------------------

--
-- Table structure for table `sells_record`
--

CREATE TABLE `sells_record` (
  `Date` date NOT NULL,
  `Serial_no` int(255) NOT NULL,
  `C_id` varchar(255) NOT NULL,
  `P_id` varchar(255) NOT NULL,
  `Quantity` int(255) NOT NULL,
  `Total_Cost` int(255) NOT NULL,
  `id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sells_record`
--

INSERT INTO `sells_record` (`Date`, `Serial_no`, `C_id`, `P_id`, `Quantity`, `Total_Cost`, `id`) VALUES
('2020-12-16', 3, 'Em-01', 'NC-1009', 3, 102, 11),
('2020-12-16', 4, 'Em-01', 'HT-1162', 6, 282, 12),
('2020-12-16', 5, 'Em-01', 'SG-1084', 2, 84, 13),
('2020-12-16', 6, 'Em-01', 'SS-1063', 1, 56, 14),
('2020-12-16', 7, 'Em-04', 'SG-1047', 3, 120, 15),
('2020-12-16', 8, 'Em-04', 'SS-1063', 6, 336, 16),
('2020-12-16', 9, 'Em-04', 'HT-1162', 2, 94, 17),
('2020-12-17', 1, 'Em-02', 'BS-1027', 10, 370, 20),
('2020-12-17', 2, 'Em-02', 'HT-1162', 5, 235, 21),
('2020-12-17', 3, 'Em-02', 'BS-1039', 7, 140, 22),
('2020-12-17', 10, 'Em-04', 'KB-1086', 4, 120, 18),
('2020-12-18', 1, 'Em-04', 'SK-1072', 5, 170, 23),
('2020-12-18', 2, 'Em-04', 'BS-1027', 3, 111, 24),
('2020-12-18', 3, 'Em-04', 'BS-1039', 9, 180, 25),
('2020-12-18', 11, 'Em-04', 'SS-1003', 3, 84, 19),
('2020-12-19', 1, 'Em-02', 'SS-1063', 3, 126, 27),
('2020-12-19', 2, 'Em-02', 'BS-1039', 2, 100, 28),
('2020-12-19', 3, 'Em-02', 'HT-1162', 5, 230, 29),
('2020-12-19', 4, 'Em-02', 'KB-1033', 6, 456, 30),
('2020-12-19', 5, 'Em-02', 'KB-1086', 4, 92, 31),
('2020-12-19', 6, 'Em-01', 'NC-1009', 5, 250, 32),
('2020-12-19', 7, 'Em-01', 'SG-1002', 4, 280, 33),
('2020-12-19', 8, 'Em-01', 'SG-1043', 1, 56, 34),
('2020-12-19', 9, 'Em-01', 'SG-1047', 3, 114, 35),
('2020-12-19', 10, 'Em-01', 'SG-1084', 2, 58, 36),
('2020-12-20', 1, 'Em-01', 'TT-1029', 3, 129, 37),
('2020-12-20', 2, 'Em-01', 'TT-1028', 2, 144, 38),
('2020-12-20', 3, 'Em-01', 'TQ-1099', 1, 68, 39),
('2020-12-20', 4, 'Em-01', 'SS-1063', 4, 168, 40),
('2020-12-20', 5, 'Em-01', 'SS-1003', 7, 280, 41),
('2020-12-20', 6, 'Em-03', 'SK-1072', 6, 288, 42),
('2020-12-20', 7, 'Em-03', 'SG-1430', 2, 70, 43),
('2020-12-20', 8, 'Em-03', 'SG-1084', 3, 87, 44),
('2020-12-20', 9, 'Em-03', 'SG-1047', 2, 76, 45),
('2020-12-20', 10, 'Em-03', 'BS-1027', 5, 165, 46),
('2020-12-21', 1, 'Em-01', 'SK-1072', 3, 144, 47),
('2020-12-21', 2, 'Em-01', 'BS-1039', 2, 100, 48),
('2020-12-21', 3, 'Em-01', 'HT-1162', 2, 92, 49),
('2020-12-21', 4, 'Em-01', 'KB-1033', 3, 228, 50),
('2020-12-21', 5, 'Em-02', 'SK-1072', 4, 192, 51),
('2020-12-21', 6, 'Em-02', 'BS-1027', 3, 99, 52),
('2020-12-21', 7, 'Em-02', 'SG-1084', 4, 116, 53),
('2020-12-21', 8, 'Em-02', 'HT-1162', 6, 276, 54),
('2020-12-21', 9, 'Em-03', 'SS-1063', 3, 126, 55),
('2020-12-21', 10, 'Em-03', 'BS-1027', 4, 132, 56),
('2020-12-21', 11, 'Em-03', 'TQ-1099', 1, 68, 57),
('2020-12-21', 12, 'Em-03', 'SG-1047', 2, 76, 58),
('2020-12-21', 13, 'Em-04', 'SK-1072', 2, 96, 59),
('2020-12-21', 14, 'Em-04', 'TT-1028', 3, 216, 60),
('2020-12-21', 15, 'Em-04', 'TQ-1099', 8, 544, 61),
('2020-12-21', 16, 'Em-04', 'HT-1162', 1, 46, 62);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `Suppliers_id` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Cata_id` varchar(50) NOT NULL,
  `Performance` int(255) NOT NULL,
  `Borrow` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`Suppliers_id`, `Name`, `Cata_id`, `Performance`, `Borrow`) VALUES
('s-10001', 'Eliza Ibara', 'CT-77', 88, 0),
('s-10002', 'Tyler Aiden', 'CT-100', 88, 0),
('s-10003', 'William Ethan', 'CT-100', 88, 0),
('s-10004', 'James Smith', 'CT-45', 88, 0),
('s-10005', 'Michael Anthony', 'CT-50', 88, 0),
('s-10006', 'William Jacob', 'CT-77', 50, 0),
('s-10007', 'Noah Samuel', 'CT-90', 88, 0),
('s-10008', 'Logaan Jackson', 'CT-90', 87, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `catalog`
--
ALTER TABLE `catalog`
  ADD PRIMARY KEY (`Cata_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`Contact_no`);

--
-- Indexes for table `counter`
--
ALTER TABLE `counter`
  ADD PRIMARY KEY (`C_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`P_id`);

--
-- Indexes for table `sells_record`
--
ALTER TABLE `sells_record`
  ADD PRIMARY KEY (`Date`,`Serial_no`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`Suppliers_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sells_record`
--
ALTER TABLE `sells_record`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
